from flask import Flask, render_template_string, request, redirect, url_for

app = Flask(__name__)

TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Tic-Tac-Toe Web</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; }
        table { margin: 20px auto; border-collapse: collapse; }
        td {
            width: 60px; height: 60px; font-size: 2em; text-align: center;
            border: 2px solid #333; cursor: pointer;
        }
        .winner { color: green; font-weight: bold; }
        .draw { color: orange; font-weight: bold; }
        .turn { margin: 10px; font-size: 1.2em; }
        button { margin-top: 20px; padding: 10px 20px; font-size: 1em; }
    </style>
</head>
<body>
    <h1>Tic-Tac-Toe</h1>
    {% if winner %}
        <div class="{{ 'winner' if winner in ['X','O'] else 'draw' }}">
            {% if winner == 'Draw' %}
                It's a draw!
            {% else %}
                Player {{ winner }} wins!
            {% endif %}
        </div>
    {% else %}
        <div class="turn">Current turn: <b>{{ current_player }}</b></div>
    {% endif %}
    <form method="post">
        <table>
            {% for i in range(3) %}
            <tr>
                {% for j in range(3) %}
                {% set idx = i*3 + j %}
                <td>
                    {% if board[idx] == " " and not winner %}
                        <button name="move" value="{{ idx }}" style="width:100%;height:100%;font-size:2em;background:none;border:none;cursor:pointer;">
                            &nbsp;
                        </button>
                    {% else %}
                        {{ board[idx] }}
                    {% endif %}
                </td>
                {% endfor %}
            </tr>
            {% endfor %}
        </table>
        <input type="hidden" name="board" value="{{ board|join(',') }}">
        <input type="hidden" name="player" value="{{ current_player }}">
        {% if winner %}
            <button type="submit" name="reset" value="1">Restart</button>
        {% endif %}
    </form>
</body>
</html>
"""

def check_winner(board):
    lines = [
        board[0:3], board[3:6], board[6:9],  # rows
        board[0:9:3], board[1:9:3], board[2:9:3],  # columns
        board[0:9:4], board[2:7:2]  # diagonals
    ]
    for line in lines:
        if line[0] != " " and line[0] == line[1] == line[2]:
            return line[0]
    if " " not in board:
        return "Draw"
    return None

@app.route("/", methods=["GET", "POST"])
def index():
    board = [" "] * 9
    current_player = "X"
    winner = None

    if request.method == "POST":
        if request.form.get("reset"):
            # Restart game
            pass
        else:
            board = request.form.get("board", " "*9).split(",")
            board = [c if c in ["X", "O", " "] else " " for c in board]
            current_player = request.form.get("player", "X")
            move = request.form.get("move")
            if move and board[int(move)] == " ":
                board[int(move)] = current_player
                winner = check_winner(board)
                if not winner:
                    current_player = "O" if current_player == "X" else "X"
            else:
                winner = check_winner(board)
    else:
        winner = check_winner(board)

    return render_template_string(
        TEMPLATE,
        board=board,
        current_player=current_player,
        winner=winner
    )

if __name__ == "__main__":
    app.run(debug=True)
